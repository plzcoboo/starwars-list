import React from 'react';
import './scss/footer.scss'

const Footer = () => {
    return (
        <footer className='footer'>
            
        </footer>
    );
};

export default Footer;